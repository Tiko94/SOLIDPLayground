import UIKit


// Single-responsibility
class RequestManager {
    func request() -> Data {
        return Data()
    }
}

class CoreDataManager {
    func saveInCoreData(_ data: Data) { }
}

class Manager {
   
    let requestManager: RequestManager
    let coreDataManager: CoreDataManager
    
    init(requestManager: RequestManager,
         coreDataManager: CoreDataManager) {
        self.requestManager = requestManager
        self.coreDataManager = coreDataManager
    }
    
    func make() {
        let data = requestManager.request()
        coreDataManager.saveInCoreData(data)
    }
}


// Open-closed
protocol Printable {
    func print() -> String
}


class IPhone: Printable {
    let model: String
    let hasCamera: Bool
    
    init(model: String, hasCamera: Bool) {
        self.model = model
        self.hasCamera = hasCamera
    }
    
    func print() -> String {
        let str = hasCamera ? "has camera" : "doesn't have camera"
        return "the iphone \(model)" + str
    }
}

class Galaxy: Printable {
    let model: String
    
    init(model:String) {
        self.model = model
    }
    func print() -> String{
        return model
    }
}

class Logger {
    func printInfo() {
        
        let phones: [Printable] = [IPhone(model: "SE", hasCamera: true),
                      IPhone(model: "2G", hasCamera: false),
                      IPhone(model: "11 Pro", hasCamera: true),
                      Galaxy(model: "S10"),
                      Galaxy(model: "S8"),
                      Galaxy(model: "S20"),]
        
        for phone in phones {
            phone.print()
        }
    }
}


//  Liskov substitution
class User {
    var gender: String?
}


class AuthService {
    func register(_ user: User) {
        if user.gender == "male" {
            // register
        }
    }
}

// Interface segregation
protocol EatProtocol {
    func eat()
}

protocol SwimProtocol {
    func swim()
}

class Fish: EatProtocol, SwimProtocol {
    func eat() {
        print("something")
    }
    
    func swim() {
        print("something")
    }
}

class Dog: EatProtocol {
    func eat() {
        print("something")
    }
}

//  Dependency Inversion
protocol Storable {}

struct ProductItem: Storable {
    let id: String
    let price: Int
    let name: String
}

protocol ProductItemsDataBaseProtocol {
    func insert(productItem: ProductItem)
    func update(productItem: ProductItem)
}

protocol DataStore {
    func insert<T>(_ data: T) where T: Storable
    func update<T>(_ data: T)  where T: Storable
    func delete(identifier: String)
}

class ProductItemsDataBaseService: ProductItemsDataBaseProtocol {
    private let dataStore: DataStore
    
    init(dataStore: DataStore) {
        self.dataStore = dataStore
    }
    
    func insert(productItem: ProductItem) {
        dataStore.insert(productItem)
    }
    
    func update(productItem: ProductItem) {
        dataStore.update(productItem)
    }

}




